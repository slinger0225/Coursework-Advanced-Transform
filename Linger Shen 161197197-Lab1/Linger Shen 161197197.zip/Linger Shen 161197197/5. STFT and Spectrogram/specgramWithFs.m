function specgramWithFs(s,nfft,fs)
specgram(s,nfft,fs);title('piccolo.wav NFFT=512');
end